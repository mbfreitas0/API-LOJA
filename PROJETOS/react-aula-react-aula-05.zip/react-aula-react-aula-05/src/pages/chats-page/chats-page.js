import React from 'react';


class ChatsPage extends React.Component {

    constructor(props) {

        super(props)

        this.state = {

        }

    }

    render() {
        return (
          <div className="container">
              <h1>Chats Page</h1>
          </div>
        )
    }

}

export default ChatsPage;

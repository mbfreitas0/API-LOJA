import React from 'react';


class HomePage extends React.Component {

    constructor(props) {

        super(props)

        this.state = {

        }

    }

    render() {
        return (
          <div className="container">
              <h1>Home Page</h1>
          </div>
        )
    }

}

export default HomePage;

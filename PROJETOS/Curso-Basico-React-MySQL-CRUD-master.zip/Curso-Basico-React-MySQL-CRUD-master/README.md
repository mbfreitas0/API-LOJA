# Curso-Basico-React-MySQL-CRUD

Tópicos abordados: --> Criando o Projeto --> Estrutura --> Select --> Details --> Insert --> Update --> Delete --> Atividade

Vídeos das aulas: https://www.youtube.com/playlist?list=PL2hDwB8DzXGOxIuijrYNrPrKcjQERQtbO

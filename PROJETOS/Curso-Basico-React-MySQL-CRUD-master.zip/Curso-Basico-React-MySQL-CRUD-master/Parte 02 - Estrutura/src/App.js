import React from 'react';
import Header from '../src/components/Header/header';

function App() {
  return (
    <div className="App">
      <Header />
    </div>
  );
}

export default App;

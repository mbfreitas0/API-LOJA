import React from "react";

export default function NormalUser() {
  return (
    <div>
      <h1>Normal User</h1>
    </div>
  );
}

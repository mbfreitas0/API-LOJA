import React from "react";

export default function Admin() {
  return (
    <div>
      <h1>Admin</h1>
      <img src="https://www.facebook.com/images/fb_icon_325x325.png" />
    </div>
  );
}

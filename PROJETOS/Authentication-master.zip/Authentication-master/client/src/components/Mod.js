import React from "react";

export default function Mod() {
  return (
    <div>
      <h1>Mod</h1>
      <img src="https://www.google.com.br/images/branding/googlelogo/2x/googlelogo_color_160x56dp.png"></img>
    </div>
  );
}

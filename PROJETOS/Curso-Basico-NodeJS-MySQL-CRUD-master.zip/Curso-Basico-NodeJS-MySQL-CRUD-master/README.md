# Curso-Basico-NodeJS-MySQL-CRUD

Tópicos abordados: --> Criando o Projeto --> Insert --> Select e Details --> Update --> Delete --> Atividade

Vídeos das aulas: https://www.youtube.com/playlist?list=PL2hDwB8DzXGPcZ2vJFbND25QNFcXMnnwU&disable_polymer=true
